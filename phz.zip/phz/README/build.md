##编译项目 build.sh

执行 `./build.sh`
