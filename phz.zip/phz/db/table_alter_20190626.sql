
-- 修改bigwin和hugewin的配置

update `s_config` set v ='[{"bigwin":20,"hugewin":40}]' where k ='spEffect';