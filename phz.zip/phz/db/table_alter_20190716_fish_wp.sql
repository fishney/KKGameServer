replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (36, "大圣捕鱼万炮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 6);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (37, "李逵劈鱼万炮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 6);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (38, "捕鱼之星万炮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 6);

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (39, "海王捕鱼万炮", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 4);

replace into `s_game` (id, title, storaterate, `type`, control) values(36, 'dashengbuyuwanpao', 98, 5, '[{"ratio":1.2},{"ratio":1.1},{"ratio":1.0},{"ratio":0.9},{"ratio":0.8}]');

replace into `s_game` (id, title, storaterate, `type`, control) values(37, 'likuipiyuwanpao', 98, 5, '[{"ratio":1.2},{"ratio":1.1},{"ratio":1.0},{"ratio":0.9},{"ratio":0.8}]');

replace into `s_game` (id, title, storaterate, `type`, control) values(38, 'buyuzhixingwanpao', 98, 5, '[{"ratio":1.2},{"ratio":1.1},{"ratio":1.0},{"ratio":0.9},{"ratio":0.8}]');

replace into `s_game` (id, title, storaterate, `type`, control) values(39, 'haiwangbuyuwanpao', 98, 5, '[{"ratio":1.2},{"ratio":1.1},{"ratio":1.0},{"ratio":0.9},{"ratio":0.8}]');
