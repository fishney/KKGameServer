
-- 吉星 167
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (167, 'jixing', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);


replace into `s_game` VALUES(167,'jixing',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 季节问候 162
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (162, 'jijiewenhou', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(162,'jijiewenhou',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);


-- 海洋天堂 160
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (160, 'haiyangtiantang', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(160,'haiyangtiantang',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 壮志凌云 169
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (169, 'zhuangzhily', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(169,'zhuangzhily',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 招财进宝 147
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (147, 'zhaocaijinbao', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(147,'zhaocaijinbao',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);


-- 劳拉 161
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (161, 'laola', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(161,'laola',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 船长9线 146
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (146, 'qiangzhoujiux', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(146,'qiangzhoujiux',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 孙悟空 165
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (165, 'sunwukong', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(165,'sunwukong',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);


-- 年年有余 144
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (144, 'niannianyouyu', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(144,'niannianyouyu',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

 -- 狂热金钱 153
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (153, 'kuangrejinqian', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(153,'kuangrejinqian',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 爱丽斯 163
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (163, 'ailisi', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(163,'ailisi',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);

-- 金钱蛙 166
replace into `s_sess`(`gameid`, `title`, `basecoin`, `mincoin`, `leftcoin`, `hot`, `status`, `ord`, `free`, `level`, `param1`, `param2`, `param3`, `param4`, `revenue`, `seat`) 
VALUES (166, 'jinqianwa', 1, 0.01, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 35, 1);
replace into `s_game` VALUES(166,'jinqianwa',1,1537170339,100,0.00,0.00,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"",0,0,0,4,"1.0.0.0",NULL);