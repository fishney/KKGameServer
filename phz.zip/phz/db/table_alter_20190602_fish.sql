replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat, chips )values (29, "大圣捕鱼", 1, 0, 1, 1, 1, 100, 0, 1, 0, 0, 0, 0, 0, 6, '[{"min":0.01,"max":0.5},{"min":0.02,"max":1},{"min":0.1,"max":10},{"min":1,"max":100}]');


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat, chips )values (30, "李逵劈鱼", 1, 0, 1, 1, 1, 100, 0, 1, 0, 0, 0, 0, 0, 6, '[{"min":0.01,"max":0.5},{"min":0.02,"max":1},{"min":0.1,"max":10},{"min":1,"max":100}]');


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat, chips )values (31, "捕鱼之星", 1, 0, 1, 1, 1, 100, 0, 1, 0, 0, 0, 0, 0, 6, '[{"min":0.01,"max":0.5},{"min":0.02,"max":1},{"min":0.1,"max":10},{"min":1,"max":100}]');

replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat, chips )values (32, "海王捕鱼918", 1, 0, 1, 1, 1, 100, 0, 1, 0, 0, 0, 0, 0, 4, '[{"min":0.01,"max":0.5},{"min":0.02,"max":1},{"min":0.1,"max":10},{"min":1,"max":100}]');

