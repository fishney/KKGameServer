replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (29, "大圣捕鱼", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 6);
replace into `s_game` (id, title, storaterate, `type`) values(29, "dashengbuyu", 98, 5);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (30, "李逵劈鱼", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 6);
replace into `s_game` (id, title, storaterate, `type`) values(30, "likuipiyu", 98, 5);


replace into `s_sess` (gameid, title, basecoin, mincoin, leftcoin, hot, status, ord, free,level, param1, param2, param3,  param4,  revenue, seat )values (31, "捕鱼之星", 1, 0, 1, 1, 1, 100, 0, 0, 0, 0, 0, 0, 0, 6);
replace into `s_game` (id, title, storaterate, `type`) values(31, "buyuzhixing", 98, 5);

