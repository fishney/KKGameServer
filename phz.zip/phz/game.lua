    [1] = --拉米
    {
        [1] =  --匹配场
        {
            [1] = --拼3张 TODO游戏暂未开发
            {
                ID = 1,
                COUNT = 10,
                STATE = 0,
                AGENT = "",
                MATCH = "FIGHT",
            },
            [2]   = --拼十
            {
                ID = 2,
                COUNT = 20,
                STATE = 1,
                AGENT = "bullagent",
                MATCH = "FIGHT",
            }, 
            [3]   = --跑得快 TODO游戏暂未开发
            {
                ID = 3,
                COUNT = 10,
                STATE = 0,
                AGENT = "",
                MATCH = "FIGHT",
            }, 
            [4]    = --拼5张 TODO游戏暂未开发
            {
                ID = 4,
                COUNT = 10,
                STATE = 0,
                AGENT = "",
                MATCH = "FIGHT",
            }, 
            [5] = --龙虎斗
            {
                ID = 5,
                COUNT = 1,
                STATE = 1,
                AGENT = "tigeragent",
                MATCH = "BET",
            }, 
            [6] = --四方大战 百人牛牛
            {
                ID = 6,
                COUNT = 1,
                STATE = 1,
                AGENT = "hbullagent",
                MATCH = "BET",
            }, 
            [8] = --拉米游戏
            {
                ID = 8,
                COUNT = 20,
                STATE = 1,
                AGENT = "mlagent",
                MATCH = "FIGHT",
            }, 
            [9] = --13水游戏(8张)
            {
                ID = 9,
                COUNT = 10,
                STATE = 1,
                AGENT = "sssagent",
                MATCH = "FIGHT",
            }, 
            [10] = --10 红黑大战 百人炸金花
            {
                ID = 10,
                COUNT = 1,
                STATE = 1,
                AGENT = "redblackwar",
                MATCH = "BET",
            },
            -- [23] = --10 红黑大战 百人炸金花
            -- {
            --     ID = 23,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "godagent",
            --     MATCH = "BET",
            -- },
            --[12] = --水浒传
            --{
            --    ID = 12,
            --    COUNT = 10,
            --    STATE = 1,
            --    AGENT = "eliminate",
            --    MATCH = 3,
            --},
             [13] = --奔驰宝马
             {
                ID = 13,
                COUNT = 10,
                STATE = 1,
                AGENT = "benzagent",
                MATCH = "BET",
             },
            --[14] = --红中麻将
            --{
            --    ID = 14,
            --    COUNT = 10,
            --    STATE = 1,
            --    AGENT = "hzmjagent",
            --    MATCH = 1,
            --},
            --[15] = --梭哈
            --{
            --    ID = 15,
            --    COUNT = 10,
            --    STATE = 1,
            --    AGENT = "studagent",
            --    MATCH = 1,
            --},
            [18] = --13水13张
            {
                ID = 18,
                COUNT = 10,
                STATE = 1,
                AGENT = "sss13agent",
                MATCH = "FIGHT",
            },
            [22] = --通比牛牛
            {
                ID = 22,
                COUNT = 10,
                STATE = 1,
                AGENT = "tbnnagent",
                MATCH = "FIGHT",
            },
            -- [100] = --拉霸
            -- {
            --     ID = 100,
            --     COUNT = 10,
            --     STATE = 0,
            --     AGENT = "godagent",
            --     MATCH = "ALONE",
            -- },
            [204] = --拉霸
            {
                ID = 204,
                COUNT = 10,
                STATE = 1,
                AGENT = "fishPrawnAgent",
                MATCH = "ALONE",
            },
            [211]   = --赛马
            {
                ID = 211,
                COUNT = 10,
                STATE = 1,
                AGENT = "horseagent",
                MATCH = "ALONE",
            },
        },
        [2] =  --房卡场
        {
            [2]   = --拼十
            {
                ID = 2,
                COUNT = 10,
                STATE = 1,
                AGENT = "bullagent",
                MATCH = "FIGHT",
            }, 
            [8] = --拉米游戏
            {
                ID = 8,
                COUNT = 10,
                STATE = 1,
                AGENT = "mlagent",
                MATCH = "FIGHT",
            }, 
            [9] = --13水游戏(8张)
            {
                ID = 9,
                COUNT = 10,
                STATE = 1,
                AGENT = "sssagent",
                MATCH = "FIGHT",
            }, 
            [11] =  --猜拳
            {
                ID = 11,
                COUNT = 10,
                STATE = 1,
                AGENT = "fgragent",
                MATCH = "FIGHT",
            },
        }
        
    },
    [2] = --瑞力
    {
        [1] =  --匹配场
        {
            [1] = --拼3张 TODO游戏暂未开发
            {
                ID = 1,
                COUNT = 10,
                STATE = 0,
                AGENT = "",
                MATCH = "FIGHT",
            },
            [2]   = --拼十
            {
                ID = 2,
                COUNT = 20,
                STATE = 1,
                AGENT = "bullagent",
                MATCH = "FIGHT",
            }, 
            [3]   = --跑得快 TODO游戏暂未开发
            {
                ID = 3,
                COUNT = 10,
                STATE = 0,
                AGENT = "",
                MATCH = "FIGHT",
            }, 
            [4]    = --拼5张 TODO游戏暂未开发
            {
                ID = 4,
                COUNT = 10,
                STATE = 0,
                AGENT = "",
                MATCH = "FIGHT",
            }, 
            [5] = --龙虎斗
            {
                ID = 5,
                COUNT = 1,
                STATE = 1,
                AGENT = "tigeragent",
                MATCH = "BET",
            }, 
            [6] = --四方大战 百人牛牛
            {
                ID = 6,
                COUNT = 1,
                STATE = 1,
                AGENT = "hbullagent",
                MATCH = "BET",
            }, 
            --[8] = --拉米游戏
            --{
            --    ID = 8,
            --    COUNT = 10,
            --    STATE = 1,
            --    AGENT = "mlagent"
            --},
            --[9] = --13水游戏(8张)
            --{
            --    ID = 9,
            --    COUNT = 10,
            --    STATE = 1,
            --    AGENT = "sssagent"
            --},
            [10] = --10 红黑大战 百人炸金花
            {
                ID = 10,
                COUNT = 1,
                STATE = 1,
                AGENT = "redblackwar",
                MATCH = "BET",
            },
            [12] = --水浒传
            {
                ID = 12,
                COUNT = 10,
                STATE = 1,
                AGENT = "eliminate",
                MATCH = "BET",
            }, 
            [13] = --奔驰宝马
            {
                ID = 13,
                COUNT = 10,
                STATE = 1,
                AGENT = "benzagent",
                MATCH = "BET",
            }, 
            [14] = --红中麻将
            {
                ID = 14,
                COUNT = 10,
                STATE = 1,
                AGENT = "hzmjagent",
                MATCH = "FIGHT",
            },
            [15] = --梭哈
            {
                ID = 15,
                COUNT = 10,
                STATE = 1,
                AGENT = "studagent",
                MATCH = "FIGHT",
            },
            [18] = --13水13张
            {
                ID = 18,
                COUNT = 20,
                STATE = 1,
                AGENT = "sss13agent",
                MATCH = "FIGHT",
            }, 
            [22] = --通比牛牛
            {
                ID = 22,
                COUNT = 10,
                STATE = 1,
                AGENT = "tbnnagent",
                MATCH = "FIGHT",
            },
            -- [23] = --10 红黑大战 百人炸金花
            -- {
            --     ID = 23,
            --     COUNT = 10,
            --     STATE = 0,
            --     AGENT = "godagent",
            --     MATCH = "BET",
            -- },
            -- [100] = --拉霸
            -- {
            --     ID = 100,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "godagent",
            --     MATCH = "ALONE",
            -- },
        },
        [2] =  --房卡场
        {
            [11] =  --猜拳
            {
                ID = 11,
                COUNT = 10,
                STATE = 1,
                AGENT = "fgragent",
                MATCH = "FIGHT",
            },
        }
    },
    [3] = --Bigbang
    {
        [1] =  --匹配场
        {
            -- [201] = --初级百家乐
            -- {
            --     ID = 201,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "baccaratagent_low",
            --     MATCH = "BET",
            -- },
            -- [221] = --中级百家乐
            -- {
            --     ID = 221,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "baccaratagent_mid",
            --     MATCH = "BET",
            -- },
            -- [218] = --高级百家乐
            -- {
            --     ID = 218,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "baccaratagent_high",
            --     MATCH = "BET",
            -- },
            -- [202]   = --猴子爬树
            -- {
            --     ID = 202,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "monkeyclimbagent",
            --     MATCH = "BET",
            -- },
            -- [203]   = --西游争霸
            -- {
            --     ID = 203,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "monkeystoryalone",
            --     MATCH = "BET",
            -- },
            -- [222]   = --西游争霸在线类
            -- {
            --     ID = 222,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "monkeystorybetonline",
            --     MATCH = "BET",
            -- },
            -- [205]   = --奔驰宝马
            -- {
            --     ID = 205,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "benzbmwagent",
            --     MATCH = "BET",
            -- },
            -- [206]   = --龙虎斗
            -- {
            --     ID = 206,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "dragontigeragent",
            --     MATCH = "BET",
            -- },
            -- [207]   = --森林舞会
            -- {
            --     ID = 207,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "forestballagent",
            --     MATCH = "BET",
            -- },
            -- [209]   = --俄罗斯轮盘初级
            -- {
            --     ID = 209,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "rouletteagent_low",
            --     MATCH = "BET",
            -- },
            -- [219]   = --俄罗斯轮盘中级
            -- {
            --     ID = 219,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "rouletteagent_mid",
            --     MATCH = "BET",
            -- },
            -- [220]   = --俄罗斯轮盘高级
            -- {
            --     ID = 220,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "rouletteagent_high",
            --     MATCH = "BET",
            -- },
            -- [210]   = --21点
            -- {
            --     ID = 210,
            --     COUNT = 5,
            --     STATE = 1,
            --     AGENT = "twentyoneagent",
            --     MATCH = "ALONE",
            -- },
            -- [211]   = --赛马
            -- {
            --     ID = 211,
            --     COUNT = 5,
            --     STATE = 1,
            --     AGENT = "horseagent",
            --     MATCH = "ALONE",
            -- },
            -- [212]   = --英超联赛
            -- {
            --     ID = 212,
            --     COUNT = 5,
            --     STATE = 1,
            --     AGENT = "premieragent",
            --     MATCH = "ALONE",
            -- },
            -- [214] = --拉霸
            -- {
            --     ID = 214,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "godofWealth",
            --     MATCH = "ALONE",
            -- },
            [24] = -- 海王捕鱼
            {
                ID = 24,
                COUNT = 10,
                STATE = 1,
                AGENT = "fishagent",
                MATCH = "FIGHT",
            },
            -- [204] = --拉霸
            -- {
            --     ID = 204,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "fishPrawnAgent",
            --     MATCH = "ALONE",
            -- },
            -- [25] = -- 悟空闹海
            -- {
            --     ID = 25,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [26] = -- 金蝉捕鱼
            -- {
            --     ID = 26,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [27] = -- 李逵捕鱼
            -- {
            --     ID = 27,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [28] = -- 摇钱树捕鱼
            -- {
            --     ID = 28,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [29] = -- 大圣捕鱼
            -- {
            --     ID = 29,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            [30] = -- 李逵劈鱼
            {
                ID = 30,
                COUNT = 4,
                STATE = 1,
                AGENT = "fishagent",
                MATCH = "FIGHT",
            },
            -- [31] = -- 捕鱼之星
            -- {
            --     ID = 31,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            [32] = -- 海王捕鱼918
            {
                ID = 32,
                COUNT = 4,
                STATE = 1,
                AGENT = "fishagent",
                MATCH = "FIGHT",
            },
            -- [33] = -- 鸟王争霸
            -- {
            --     ID = 33,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [34] = -- 雷电捕鱼
            -- {
            --     ID = 34,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [35] = -- 海绵宝宝
            -- {
            --     ID = 35,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [36] = -- 大圣捕鱼万炮版
            -- {
            --     ID = 36,
            --     COUNT = 4,
            --     STATE = 0,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            [37] = -- 李逵劈鱼万炮版
            {
                ID = 37,
                COUNT = 4,
                STATE = 0,
                AGENT = "fishagent",
                MATCH = "FIGHT",
            },
            -- [38] = -- 捕鱼之星万炮版
            -- {
            --     ID = 38,
            --     COUNT = 4,
            --     STATE = 0,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            [39] = -- 海王捕鱼918万炮版
            {
                ID = 39,
                COUNT = 4,
                STATE = 0,
                AGENT = "fishagent",
                MATCH = "FIGHT",
            },
            -- [40] = -- 虫虫乐园
            -- {
            --     ID = 40,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [41] = -- 渔人码头
            -- {
            --     ID = 41,
            --     COUNT = 4,
            --     STATE = 1,
            --     AGENT = "fishagent",
            --     MATCH = "FIGHT",
            -- },
            -- [208] = --飞禽走兽
            -- {
            --     ID = 208,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "birdsagent",
            --     MATCH = "BET",
            -- },
            -- [211]   = --赛马
            -- {
            --     ID = 211,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "horseagent",
            --     MATCH = "ALONE",
            -- },
            -- [212] = -- 英超联赛
            -- {
            --     ID = 212,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "premieragent",
            --     MATCH = "ALONE",
            -- },
            -- [213] = -- 经典水果机 
            -- {   
            --     ID = 213,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "classicfruit777",
            --     MATCH = "BET",
            -- },
            -- [215] = -- 绝地求生
            -- {
            --     ID = 215,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "jedisurvivalagent",
            --     MATCH = "BET",
            -- },
            -- [101] ={   -- 旧的28款游戏的拉霸
            --     ID = 101,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "godagent",
            --     MATCH = "ALONE",
            -- },
            [100] = --拉霸
            {
                ID = 100,
                COUNT = 10,
                STATE = 1,
                AGENT = "slotsagent",
                MATCH = "ALONE",
            },
            -- [216] = -- 葫芦机 
            -- {   
            --     ID = 216,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "hulujiagent",
            --     MATCH = "BET",
            -- },
            -- [30201] = --evo视频百家乐
            -- {
            --     ID = 30201,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "evo_baccaratagent",
            --     MATCH = "BET",
            -- },
            -- [30206] = --龙虎斗视频
            -- {
            --     ID = 30206,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "evo_dragontigeragent",
            --     MATCH = "BET",
            -- },
            -- [30210] =--21点视频
            -- {
            --     ID = 30210,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "evo_twentyoneagent",
            --     MATCH = "BET",
            -- },
            -- [30209] = --俄罗斯视频
            -- {
            --     ID = 30209,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "evo_rouletteagent",
            --     MATCH = "BET",
            -- },
            -- [238] = -- 五龙
            -- {
            --     ID = 238,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "fivedragonagnet",
            --     MATCH = "BET"
            -- },
            -- [226] = --龙虎斗单机1
            -- {
            --     ID = 226,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "dragontigeralone1",
            --     MATCH = "BET",
            -- },
            -- [227] = --龙虎斗单机2
            -- {
            --     ID = 227,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "dragontigeralone2",
            --     MATCH = "BET",
            -- },
            -- [228] = --龙虎斗单机3
            -- {
            --     ID = 228,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "dragontigeralone3",
            --     MATCH = "BET",
            -- },
            -- [236] = --赛摩托车
            -- {
            --     ID = 236,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "raceagent",
            --     MATCH = "BET",
            -- },
            [229] = --豹子王单机
            {
                ID = 229,
                COUNT = 10,
                STATE = 1,
                AGENT = "godofwealthalone",
                MATCH = "BET",
            },
            -- [237] = --新奔驰宝马单机
            -- {
            --     ID = 237,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "newbenzbmagent",
            --     MATCH = "BET",
            -- },
            -- [230] = --百家乐单机
            -- {
            --     ID = 230,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "baccaratalone",
            --     MATCH = "BET",
            -- },
            -- [231] = --三卡扑克单机
            -- {
            --     ID = 231,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "threecardalone",
            --     MATCH = "BET",
            -- },
            -- [234] = --牛牛单机
            -- {
            --     ID = 234,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "nnaloneagent",
            --     MATCH = "BET",
            -- },
            -- [232] = --赌场单机
            -- {
            --     ID = 232,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "casinoholdalone",
            --     MATCH = "BET",
            -- },
            -- [235] = --单挑
            -- {
            --     ID = 235,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "singlepickagent",
            --     MATCH = "BET",
            -- },
            -- [233] = --赌场战争单机
            -- {
            --     ID = 233,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "casinowaralone",
            --     MATCH = "BET",
            -- },
            -- [224] = --俄罗斯轮盘24单机
            -- {
            --     ID = 224,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "roulettealone24",
            --     MATCH = "BET",
            -- },
            -- [223] = --俄罗斯轮盘mini单机
            -- {
            --     ID = 223,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "roulettealonemini",
            --     MATCH = "BET",
            -- },
            -- [239] = --俄罗斯轮盘36单机
            -- {
            --     ID = 239,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "roulettealone36",
            --     MATCH = "BET",
            -- },
            -- [225] = --俄罗斯轮盘72单机
            -- {
            --     ID = 225,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "roulettealone72",
            --     MATCH = "BET",
            -- },
            -- [240] = --918西游争霸单机
            -- {
            --     ID = 240,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "monkeystory918alone",
            --     MATCH = "BET",
            -- },
            -- [241] = --918战无不胜单机
            -- {
            --     ID = 241,
            --     COUNT = 10,
            --     STATE = 1,
            --     AGENT = "invinciblealone",
            --     MATCH = "BET",
            -- },
            -- [242] = -- 经典水果机918
            -- {   
            --     ID = 242,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "classicfruit918",
            --     MATCH = "BET",
            -- },
            -- [243] = --赛马918
            -- {
            --     ID = 243,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "raceagent",
            --     MATCH = "BET",
            -- },
            -- [245] = -- 战无不胜在线
            -- {   
            --     ID = 245,
            --     COUNT = 1,
            --     STATE = 1,
            --     AGENT = "invinciblebetonline",
            --     MATCH = "BET",
            -- },
			-- [246] = -- 猜大小在线
   --          {   
   --              ID = 246,
   --              COUNT = 1,
   --              STATE = 1,
   --              AGENT = "guessbigsmallagent",
   --              MATCH = "BET",
   --          },
        }
    },