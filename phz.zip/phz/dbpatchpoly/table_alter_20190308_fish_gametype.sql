replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (4, 29, "大圣捕鱼", 1, 60);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (4, 30, "李逵劈鱼", 1, 70);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (4, 31, "捕鱼之星", 1, 80);

