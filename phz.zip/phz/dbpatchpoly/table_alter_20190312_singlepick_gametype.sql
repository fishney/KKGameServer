replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (4, 235, "单挑", 1, 100);

