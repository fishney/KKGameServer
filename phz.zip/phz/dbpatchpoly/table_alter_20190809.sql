replace into s_config (id, k,v,memo) values(32, 'res_version_url', 'https://global.poly99online.com/poly99/hotupdate/manifest/hall_version.manifest', '资源版本热更地址');
