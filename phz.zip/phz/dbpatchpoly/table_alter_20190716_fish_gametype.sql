replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (5, 36, "大圣捕鱼万炮", 1, 16);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (5, 37, "李逵劈鱼万炮", 1, 21);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (5, 38, "捕鱼之星万炮", 1, 26);
replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (5, 39, "海王捕鱼万炮", 1, 11);

