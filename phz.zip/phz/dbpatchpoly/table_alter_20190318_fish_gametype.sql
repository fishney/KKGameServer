replace into `s_game_type` (gametype, gameid, title, state, hot)  VALUES (4, 32, "海王捕鱼918", 1, 90);

